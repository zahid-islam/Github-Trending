import { UserModel, RepositoryModel } from './../models/user.model';
import { GithubService } from './../services/github.service';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-top-repository-by-star',
  templateUrl: './top-repository-by-star.component.html',
  styleUrls: ['./top-repository-by-star.component.css']
})
export class TopRepositoryByStarComponent implements OnInit {
  @ViewChild("repoModal", { static: false }) repoModal: ElementRef;

  repositoryList: RepositoryModel[] = [];
  repository: RepositoryModel = null;

  page = 1;
  per_page = 10;
  config: any;
  totalCount = 0;

  constructor(private githubService: GithubService) {
    this.config = {
      itemsPerPage: 10,
      currentPage: 1,
      totalItems: this.totalCount
    };
  }

  ngOnInit(): void {
    this.searchRepositoryByStar();
  }

  searchRepositoryByStar() {
    this.githubService.searchRepositoryByStar(this.page, this.per_page).subscribe(
      (res: any) => {
        this.repositoryList = [];
        res.body.items.forEach(item => {
          let repository: RepositoryModel = new RepositoryModel();
          repository.id = item.id;
          repository.name = item.owner.login;
          repository.fullName = item.full_name;
          repository.image = item.owner.avatar_url;
          repository.star = item.watchers;
          repository.score = item.score;

          this.repositoryList.push(repository);
        });

        this.totalCount = res.body.total_count;
        this.config.totalItems = this.totalCount;
      },
      err => {
      }
    );
  }

  openReposiotryDetails(repo: RepositoryModel) {
    this.repository = repo;
    this.repoModal.nativeElement.style.display = "block";
  }

  closeRepoModal() {
    this.repoModal.nativeElement.style.display = "none";
    this.repository = null;
  }

  pageChanged(event) {
    this.config.currentPage = event;
    this.page = event;
    this.searchRepositoryByStar();
  }

}
