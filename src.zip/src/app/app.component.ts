import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'GithubTrending';
  activeLink = 'home';

  constructor(private router: Router) { }

  navigateUserPage() {
    this.activeLink = 'user';
    this.router.navigateByUrl('search/users');
  }

  navigateRepoPage() {
    this.activeLink = 'repo';
    this.router.navigateByUrl('search/repositories');
  }

  navigateHomePage() {
    this.activeLink = 'home';
    this.router.navigateByUrl('');
  }

}
