import { TopRepositoryByStarComponent } from './top-repository-by-star/top-repository-by-star.component';
import { TopUserByCountyComponent } from './top-user-by-county/top-user-by-county.component';
import { UsersComponent } from './users/users.component';
import { NgModule } from '@angular/core';

import { Routes, RouterModule } from "@angular/router";

const routes: Routes = [
  {
    path: "",
    component: UsersComponent
  },
  {
    path: "search/users",
    component: TopUserByCountyComponent
  },
  {
    path: "search/repositories",
    component: TopRepositoryByStarComponent
  },
  {
    path: "**",
    redirectTo: "",
  }
];

@NgModule({
  declarations: [],
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
