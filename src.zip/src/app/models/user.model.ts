export class UserModel {
    id: number;
    name: string;
    image: string;
    score: number;
}

export class RepositoryModel {
    id: number;
    name: string;
    fullName: string;
    image: string;
    score: number;
    star: number;
}