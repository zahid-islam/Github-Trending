import { UserModel, RepositoryModel } from './../models/user.model';
import { GithubService } from './../services/github.service';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  viewMode = 'userTab';
  totalCount = 0;
  searchString = null;

  userList: UserModel[] = [];
  repositoryList: RepositoryModel[] = [];

  user: UserModel = null;
  repository: RepositoryModel = null;


  @ViewChild("userModal", { static: false }) userModal: ElementRef;
  @ViewChild("repoModal", { static: false }) repoModal: ElementRef;

  constructor(private githubService: GithubService) { }

  ngOnInit(): void {
  }

  searchByUserOrRepository() {
    if (this.searchString !== null) {
      this.githubService.searchByUser(this.searchString).subscribe(
        (res: any) => {
          res.body.items.forEach(item => {
            let user: UserModel = new UserModel();
            user.id = item.id;
            user.name = item.login;
            user.image = item.avatar_url;
            user.score = item.score;

            this.userList.push(user);
          });
        },
        err => {
        }
      );

      this.githubService.searchByRepository(this.searchString).subscribe(
        (res: any) => {
          res.body.items.forEach(item => {
            let repository: RepositoryModel = new RepositoryModel();
            repository.id = item.id;
            repository.name = item.owner.login;
            repository.fullName = item.full_name;
            repository.image = item.owner.avatar_url;
            repository.star = item.watchers;
            repository.score = item.score;

            this.repositoryList.push(repository);
          });
        },
        err => {
        }
      );

      this.searchString !== null
    }
  }

  openUserDetails(user: UserModel) {
    this.user = user;
    this.userModal.nativeElement.style.display = "block";
  }

  closeUserModal() {
    this.userModal.nativeElement.style.display = "none";
    this.user = null;
  }

  openReposiotryDetails(repo: RepositoryModel) {
    this.repository = repo;
    this.repoModal.nativeElement.style.display = "block";
  }

  closeRepoModal() {
    this.repoModal.nativeElement.style.display = "none";
    this.repository = null;
  }

}
