import { ApiService } from './api.service';
import { UtilityService } from './utility.service';
import { Injectable } from '@angular/core';
import { HttpParams } from "@angular/common/http";
import { map } from "rxjs/operators";

@Injectable({
  providedIn: 'root'
})
export class GithubService {

  constructor(private utilityService: UtilityService,
    private apiService: ApiService) { }


  searchByUser(searchString: string) {
    let params = new HttpParams().set("q", searchString);
    return this.apiService
      .getWithParam(this.utilityService.getApiEndPointUrl("users"), params)
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  searchByRepository(searchString: string) {
    let params = new HttpParams().set("q", searchString);
    return this.apiService
      .getWithParam(this.utilityService.getApiEndPointUrl("repositories"), params)
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  searchUserByCountry(country: string, page: number, per_page: number) {
    let queryString = `location:${country}+followers`;
    let params = new HttpParams().set("q", queryString)
      .set("page", page.toString()).set("per_page", per_page.toString());
    return this.apiService
      .getWithParam(this.utilityService.getApiEndPointUrl("users"), params)
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  searchRepositoryByStar(page: number, per_page: number) {
    let sortBy = "stars";
    let orderBy = "desc"
    let queryString = "stars";
    let params = new HttpParams().set("q", queryString)
      .set("sort", sortBy).set("order", orderBy)
      .set("page", page.toString()).set("per_page", per_page.toString());;
    return this.apiService
      .getWithParam(this.utilityService.getApiEndPointUrl("repositories"), params)
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

}
