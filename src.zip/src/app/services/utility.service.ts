import { Injectable } from "@angular/core";
import { UserModel } from "../models/user.model";

@Injectable({
  providedIn: "root"
})
export class UtilityService {
  baseURL: string;

  resolvedEndPoint: any = {};

  constructor() {
    this.baseURL = "https://api.github.com/search";
  }

  public getApiEndPointUrl(routePath: string): string {
    return `${this.baseURL}/${routePath}`;
  }

}
