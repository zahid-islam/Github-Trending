import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { UserModel, RepositoryModel } from './../models/user.model';
import { GithubService } from './../services/github.service';

@Component({
  selector: 'app-top-user-by-county',
  templateUrl: './top-user-by-county.component.html',
  styleUrls: ['./top-user-by-county.component.css']
})
export class TopUserByCountyComponent implements OnInit {
  @ViewChild("userModal", { static: false }) userModal: ElementRef;
  @ViewChild("repoModal", { static: false }) repoModal: ElementRef;

  selectedCountry = 'Bangladesh';

  userList: UserModel[] = [];
  user: UserModel = null;

  page = 1;
  per_page = 10;
  config: any;
  totalCount = 0;

  constructor(private githubService: GithubService) {
    this.config = {
      itemsPerPage: 10,
      currentPage: 1,
      totalItems: this.totalCount
    };
  }

  ngOnInit(): void {
    this.getUserListByCountry();
  }

  getUserListByCountry() {
    this.githubService.searchUserByCountry(this.selectedCountry, this.page, this.per_page).subscribe(
      (res: any) => {
        this.userList = [];
        res.body.items.forEach(item => {
          let user: UserModel = new UserModel();
          user.id = item.id;
          user.name = item.login;
          user.image = item.avatar_url;
          user.score = item.score;

          this.userList.push(user);
        });

        this.totalCount = res.body.total_count;
        this.config.totalItems = this.totalCount;
      },
      err => {
      }
    );
  }

  openUserDetails(user: UserModel) {
    this.user = user;
    this.userModal.nativeElement.style.display = "block";
  }

  closeUserModal() {
    this.userModal.nativeElement.style.display = "none";
    this.user = null;
  }

  pageChanged(event) {
    this.config.currentPage = event;
    this.page = event;
    this.getUserListByCountry();
  }

}
